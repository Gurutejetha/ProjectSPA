import React, { useState } from 'react';
import { Modal, Button, Form, Row, Col } from 'react-bootstrap';
import { FaPhone, FaEnvelope, FaIdCard, FaCar, FaCalendarAlt, FaUser } from 'react-icons/fa';

const ApplicationModal = ({ policy, onClose, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    email: '',
    contactNumber: '',
    vehicleNumber: '',
    licenseNumber: '',
    licenseExpiry: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    if (errors[name]) {
      setErrors({ ...errors, [name]: null });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.age || isNaN(formData.age) || formData.age < 18 || formData.age > 100) newErrors.age = 'Age must be between 18 and 100';
    if (!formData.email.trim() || !/^\S+@\S+\.\S+$/.test(formData.email)) newErrors.email = 'Valid email is required';
    if (!/^\d{10}$/.test(formData.contactNumber)) newErrors.contactNumber = 'Contact number must be 10 digits';
    if (!/^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$/.test(formData.vehicleNumber)) newErrors.vehicleNumber = 'Format: XX00XX0000';
    if (!/^[A-Z]{2}\d{2}\d{11}$/.test(formData.licenseNumber)) newErrors.licenseNumber = 'Format: XX00XXXXXXXXXXX';
    const expiryDate = new Date(formData.licenseExpiry);
    if (!formData.licenseExpiry || expiryDate <= new Date()) newErrors.licenseExpiry = 'Date must be in future';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      fetch("http://localhost:5000/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...formData, policyId: policy._id })
      })
        .then(res => res.json())
        .then(() => {
          onSuccess();
          onClose();
        })
        .catch(err => {
          console.error("Submission error", err);
        });
    }
  };

  return (
    <Modal show onHide={onClose} size="lg" centered backdrop="static" keyboard={false}>
      <Modal.Header>
        <div className="d-flex align-items-center w-100">
          <img src={require("./logos.png")} alt="Logo" style={{ width: "50px", height: "50px", marginTop: "20px" }} />
          <Modal.Title className="ms-3">Apply for {policy?.name}</Modal.Title>
        </div>
      </Modal.Header>
      <Modal.Body className="p-4">
        <Form onSubmit={handleSubmit}>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaUser className="me-2" />Name</Form.Label>
                <Form.Control type="text" name="name" value={formData.name} onChange={handleChange} isInvalid={!!errors.name} />
                <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaUser className="me-2" />Age</Form.Label>
                <Form.Control type="number" name="age" value={formData.age} onChange={handleChange} isInvalid={!!errors.age} />
                <Form.Control.Feedback type="invalid">{errors.age}</Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaEnvelope className="me-2" />Email</Form.Label>
                <Form.Control type="email" name="email" value={formData.email} onChange={handleChange} isInvalid={!!errors.email} />
                <Form.Control.Feedback type="invalid">{errors.email}</Form.Control.Feedback>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaPhone className="me-2" />Contact Number</Form.Label>
                <Form.Control type="text" name="contactNumber" value={formData.contactNumber} onChange={handleChange} isInvalid={!!errors.contactNumber} />
                <Form.Control.Feedback type="invalid">{errors.contactNumber}</Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaCar className="me-2" />Vehicle Number</Form.Label>
                <Form.Control type="text" name="vehicleNumber" value={formData.vehicleNumber} onChange={handleChange} isInvalid={!!errors.vehicleNumber} />
                <Form.Control.Feedback type="invalid">{errors.vehicleNumber}</Form.Control.Feedback>
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaIdCard className="me-2" />License Number</Form.Label>
                <Form.Control type="text" name="licenseNumber" value={formData.licenseNumber} onChange={handleChange} isInvalid={!!errors.licenseNumber} />
                <Form.Control.Feedback type="invalid">{errors.licenseNumber}</Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label><FaCalendarAlt className="me-2" />License Expiry Date</Form.Label>
                <Form.Control type="date" name="licenseExpiry" value={formData.licenseExpiry} onChange={handleChange} isInvalid={!!errors.licenseExpiry} />
                <Form.Control.Feedback type="invalid">{errors.licenseExpiry}</Form.Control.Feedback>
              </Form.Group>
            </Col>
          </Row>
          <div className="d-flex justify-content-end mt-4">
            <Button onClick={onClose} className="me-2" style={{ backgroundColor: "#8a2be2" }}>Cancel</Button>
            <Button type="submit" style={{ backgroundColor: "#ff69b2" }}>Submit</Button>
          </div>
        </Form>
      </Modal.Body>
    </Modal>
  );
};

export default ApplicationModal;