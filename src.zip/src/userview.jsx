import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, Col, Container, Row, Alert, Button } from 'react-bootstrap';
import { FaCheck, FaExclamationTriangle } from 'react-icons/fa';
import ApplicationModal from './applyForm';
import './styles.css';
import 'bootstrap/dist/css/bootstrap.min.css';

const UserView = () => {
  const [policies, setPolicies] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [selectedPolicy, setSelectedPolicy] = useState(null);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const [serverError, setServerError] = useState(false);

  useEffect(() => {
    fetch('http://localhost:5000/api/policies')
      .then(res => {
        if (!res.ok) throw new Error('Server busy, try again later');
        return res.json();
      })
      .then(data => {
        setPolicies(data);
        setServerError(false);
      })
      .catch(err => {
        console.error("Error fetching policies", err);
        setServerError(true);
      });
  }, []);

  const handleShowModal = (policy) => {
    setSelectedPolicy(policy);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <Container fluid className="p-0">
      <div className="py-3 shadow-sm">
        <Container>
          <div className="d-flex align-items-center justify-content-between">
            <div className="d-flex align-items-center">
              <img
                src={require("./logos.png")}
                alt="Logo"
                style={{ width: "50px", height: "50px", marginTop: "15px" }}
              />
              <h1 className="mb-0">Vehicle Insurance Policies</h1>
            </div>
          </div>
        </Container>
      </div>

      {showSuccessMessage && (
        <Alert variant="success" className="shadow-sm" onClose={() => setShowSuccessMessage(false)} dismissible>
          <div className="d-flex align-items-center">
            <FaCheck className="me-2 success-icon" style={{ color: "green" }} />
            <span>Application submitted successfully!</span>
          </div>
        </Alert>
      )}

      {serverError && (
        <div className="modal show d-block" tabIndex="-1" role="dialog">
          <div className="modal-dialog modal-dialog-centered" role="document">
            <div className="modal-body">
              <div className="d-flex align-items-center">
                <FaExclamationTriangle className="me-2 error-icon" style={{ marginLeft: "100px", color: "red" }} />
                <span>Server busy, please try again later.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <Container className="py-4">
        <Row className="g-4">
          {policies.map(policy => (
            <Col lg={4} md={6} sm={12} key={policy._id}>
              <Card className="policy-card h-100 shadow-sm">
                <Card.Header>
                  <div className="d-flex align-items-center">
                    <img
                      src={require(`./${policy.logo}`)}
                      alt={policy.name}
                      style={{ width: "120px", height: "120px", marginTop: "30px" }}
                    />
                    <div className="ms-3">
                      <Card.Title className="mb-0">{policy.name}</Card.Title>
                    </div>
                  </div>
                </Card.Header>
                <Card.Body>
                  <Card.Text className="policy-description">{policy.description}</Card.Text>
                  <div className="policy-features">
                    <div className="feature"><span className="feature-label">Coverage:</span> <span>{policy.coverage || "Comprehensive"}</span></div>
                    <div className="feature"><span className="feature-label">Premium:</span> <span>{policy.premium || "Based on vehicle value"}</span></div>
                  </div>
                </Card.Body>
                <Card.Footer className="bg-white border-0 pt-0">
                  <div className="d-flex justify-content-between">
                    <Link to={`/policy/${policy._id}`} className="btn" style={{ backgroundColor: "#8a2be2", color: "white" }}>View Details</Link>
                    <Button style={{ backgroundColor: "#ff69b4", border: "none" }} onClick={() => handleShowModal(policy)}>Apply Now</Button>
                  </div>
                </Card.Footer>
              </Card>
            </Col>
          ))}
        </Row>
      </Container>

      {showModal && (
        <ApplicationModal
          policy={selectedPolicy}
          onClose={handleCloseModal}
          onSuccess={() => {
            setShowSuccessMessage(true);
            setTimeout(() => setShowSuccessMessage(false), 2000);
          }}
        />
      )}
    </Container>
  );
};

export default UserView;
