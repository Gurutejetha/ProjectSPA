import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import "bootstrap/dist/css/bootstrap.min.css";

const UserView2 = () => {
  const { id } = useParams();
  const [policy, setPolicy] = useState(null);
  
  useEffect(() => {
    fetch(`http://localhost:5000/api/policies/${id}`)
      .then(res => res.json())
      .then(data => {
        setPolicy(data)})
      .catch(err => console.error("Error loading policy", err));
  }, [id]);
  
  if (!policy) {
    return (
      <div className="container mt-5 text-center">
        <div className="alert alert-danger">Policy not found</div>
      </div>
    );
  }
  return (
    <div className="container mt-4">
      <nav className="navbar navbar-light d-flex justify-content-between align-items-center mb-4 rounded shadow-sm" 
           style={{ background: 'linear-gradient(to right, #f8f9fa, #e9ecef)'}}>
        <div className="d-flex align-items-center">
          <img src={require("./logos.png")} alt="Logo" 
               style={{ width: "70px", height: "70px", marginRight: "10px", marginTop: "25px" }} />
          <h3 className="navbar-brand mb-0 h1" style={{ fontSize: "30px", color: "#444" }}>
            Vehicle Insurance
          </h3>
        </div>
        <Link to="/" className="btn" 
              style={{ backgroundColor: "#ff69b4", color: "white", border: "none",marginRight:"50px" }}>
        Back
        </Link>
      </nav>
      <div className="card border-0 shadow-sm overflow-hidden mb-5">
        <div className="card-header border-0 py-3" 
             style={{ background: "#8a2be2", color: "white", opacity:"0.75" }}>
          <h5 className="m-0">Policy Details</h5>
        </div>
        <div className="card-body p-0">
          <div className="row g-0">
            <div className="col-md-4 border-end d-flex flex-column align-items-center justify-content-center py-4">
              <div className="mb-3">
                <img 
                  src={require(`./${policy.logo}`)} 
                  alt={policy.name} 
                  style={{ 
                    width: "120px", 
                    height: "120px", 
                    filter: "drop-shadow(0px 4px 6px rgba(0,0,0,0.1))" 
                  }} 
                />
              </div>
              <h4 className="mt-2 mb-3">{policy.name}</h4>
            </div>
            <div className="col-md-8">
              <div className="row g-4 p-4">
                <div className="col-md-6">
                  <div className="fw-bold text-secondary mb-1">Premium Cost</div>
                  <div className="fs-5 fw-bold">
                    {policy.premium}
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="fw-bold text-secondary mb-1">Coverage Amount</div>
                  <div className="fs-5 fw-bold">
                    {policy.coverage}
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="fw-bold text-secondary mb-1">Start Date</div>
                  <div className="fs-5">
                    {policy.startDate}
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="fw-bold text-secondary mb-1">End Date</div>
                  <div className="fs-5">
                    {policy.endDate}
                  </div>
                </div>
                {policy.description && (
                  <div className="col-12">
                    <div className="fw-bold text-secondary mb-1">Policy Description</div>
                    <div className="fs-6 mt-1">
                      {policy.description}
                    </div>
                  </div>
                )}
                {policy.addOns && policy.addOns.length > 0 && (
                  <div className="col-md-6">
                    <div className="fw-bold text-secondary mb-2">Add-Ons</div>
                    <ul className="list-group list-group-flush">
                      {policy.addOns.map((addon, idx) => (
                        <li key={idx} className="list-group-item ps-0 border-0 py-1">
                          <span className="text-success me-2">✓</span>
                          {addon}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {policy.exclusions && policy.exclusions.length > 0 && (
                  <div className="col-md-6">
                    <div className="fw-bold text-secondary mb-2">Exclusions</div>
                    <ul className="list-group list-group-flush">
                      {policy.exclusions.map((exclusion, idx) => (
                        <li key={idx} className="list-group-item ps-0 border-0 py-1">
                          <span className="text-danger me-2">×</span>
                          {exclusion}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserView2;