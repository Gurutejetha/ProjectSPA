import React from 'react';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import Userview from './userview'
import Userview2 from './userView2';

const App=()=>{
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Userview/>}/>
        <Route path="/policy/:id" element={<Userview2/>}/>
      </Routes>
    </Router>
  );
};
 
export default App;