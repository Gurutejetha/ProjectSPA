import React,{useState,useContext} from 'react';
import {Link} from 'react-router-dom';
import { PolicyContext } from './PolicyContext';
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles.css";

const PoliciesPage=()=>{
    const [showForm, setShowForm]=useState(false);
    const {policies,addPolicy}=useContext(PolicyContext);
    const [policyDetails, setPolicyDetails]=useState({
        policyName:'',
        premiumAmount:'',
        coverageAmount:'',
        startDate:'',
        endDate:'',
        description:''
    });
    const create=()=>{
        setShowForm(true);
    }
    const back=()=>{
        setShowForm(false);
    }
    const handleChange=(e)=>{
        const {name,value}=e.target;
        setPolicyDetails({
            ...policyDetails,
            [name]: value,
        });
    }
    const handleSubmit = (e) => {
        e.preventDefault();
        const newPolicy = {
          name: policyDetails.policyName,
          logo: "insure.png",
          description: policyDetails.description,
          premium: `Rs.${policyDetails.premiumAmount}/month`, 
          coverage: `Rs.${policyDetails.coverageAmount}`,
          startDate: policyDetails.startDate,
          endDate: policyDetails.endDate, 
        };
        addPolicy(newPolicy);
        setShowForm(false);
      };
      
      const [policyList,setPolicyList]=useState(policies);
      
      const deletePolicy=(index)=>{
        const updatedPolicies=policyList.filter((_,i)=>i!==index);
        
        setPolicyList(updatedPolicies);
      }
    return(
        <div>
        {showForm?(
            <div className='container mt-4'>
            <nav className='navbar navbar-light bg-light d-flex justify-content-between align-items-center'>
                <div className='d-flex align-items-center'>
                <img src={require("./logos.png")} alt="Navbar Icon" style={{width:"70px",height:"70px",marginRight:"10px",marginTop:"25px"}}/>
                <h3 className="navbar-brand mb-0 h1" style={{fontSize:"30px"}}>Vehicle Policies</h3>
                </div>
                <button onClick={back} className='btn btn-secondary' style={{backgroundColor:"#ff69b4"}}>Back</button>
            </nav>
            <div className="d-flex justify-content-center align-items-center" style={{ height: '100vh',marginTop:'20px'}}>
            <div className="p-4" style={{ backgroundColor: '#f8f9fa', borderRadius: '10px', width: '50%', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)' }}>
              <div className="d-flex align-items-center mb-1 mt-5 justify-content-center">
                <h2 className="text-center" style={{ color: '#8a2be2' }}>New Policy</h2>
              </div>
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label htmlFor="policyName" className="form-label" style={{marginTop:"-100px"}}>Policy Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="policyName"
                    name="policyName"
                    value={policyDetails.policyName}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="premiumAmount" className="form-label">Premium Amount</label>
                  <input
                    type="number"
                    className="form-control"
                    id="premiumAmount"
                    name="premiumAmount"
                    value={policyDetails.premiumAmount}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="coverageAmount" className="form-label">Coverage Amount</label>
                  <input
                    type="number"
                    className="form-control"
                    id="coverageAmount"
                    name="coverageAmount"
                    value={policyDetails.coverageAmount}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="startDate" className="form-label">Start Date</label>
                  <input
                    type="date"
                    className="form-control"
                    id="startDate"
                    name="startDate"
                    value={policyDetails.startDate}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="endDate" className="form-label">End Date</label>
                  <input
                    type="date"
                    className="form-control"
                    id="endDate"
                    name="endDate"
                    value={policyDetails.endDate}
                    onChange={handleChange}
                    required/>
                </div>
                <div className="mb-3">
                  <label htmlFor="description" className="form-label">Description</label>
                  <textarea
                    rows="5"
                    cols="50"
                    className="form-control"
                    id="description"
                    name="description"
                    placeholder='enter policy details'
                    value={policyDetails.description}
                    onChange={handleChange}
                    required/>
                </div>
                <button type="submit" className="btn btn-primary w-50" style={{marginLeft:'140px' ,backgroundColor: '#8a2be2', borderColor: 'skyblue' }}>Create Policy</button>
              </form>
            </div>
          </div>
          </div>
        ):(
        <div className="container mt-4">
            <nav className="navbar navbar-light bg-light">
                <div className="d-flex align-items-center">
                    <img src={require("./logos.png")} alt="Navbar Icon" style={{width:"70px",height:"70px",marginRight:"10px",marginTop:"25px"}}/>
                <span className="navbar-brand mb-0 h1" style={{fontSize:"30px"}}>Vehicle Policies</span>
                </div>
                <button className="btn" onClick={create} style={{backgroundColor:"#8a2be2",color:"white"}}>Create</button>
            </nav>
            <div className="row mt-4">
                {policyList.map((policy,index)=>(
                    <div className="col-md-4 mb-3" key={index}>
                    <div >
                        <Link to={`/policy/${index}`} style={{textDecoration:"none"}}>
                        <button className="policy-button btn w-100 p-3 text-start d-flex flex-column align-items-start">
                            <div className="d-flex align-items-center" style={{width:"100%"}}>
                            <img src={require(`./${policy.logo}`)} alt={policy.name} style={{width:"150px",height:"150px"}}/>
                            <span className="ms-2 d-flex align-items-center" style={{height:"35px",fontWeight:"bold"}}>{policy.name}</span>
                            </div>
                            <p className="mb-0 small mt-2 text-justify" style={{marginLeft:"37px",marginLeft:"37px"}}>{policy.description}</p>
                        </button>
                        </Link>
                    </div>
                        <button className='btn w-45' onClick={()=>deletePolicy(index)} style={{backgroundColor:"#8a2be2",color:"white",textAlign:"center",marginTop:"30px",marginLeft:"120px"}}>Delete</button>
                    </div>
                ))}
            </div>
        </div>
        )}
        </div>
    )
}
export default PoliciesPage