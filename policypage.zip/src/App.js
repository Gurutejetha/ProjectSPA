import React from 'react';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import PoliciesPage from './PoliciesPage';
import PolicyDetails from './PolicyDetails';
import { PolicyProvider } from './PolicyContext';
function Apps(){
  return (
    <PolicyProvider>
    <Router>
      <Routes>
        <Route path="/" element={<PoliciesPage/>}/>
        <Route path="/policy/:id" element={<PolicyDetails/>}/>
      </Routes>
    </Router>
    </PolicyProvider>
  );
};

export default Apps;
