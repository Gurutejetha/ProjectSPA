import React,{ createContext,useState } from "react";
export const PolicyContext=createContext();
export const PolicyProvider=({children})=>{
    const [policies,setPolicies]=useState([
        {name: "Car Insurance",logo: "car.png",
            description: "Protects your vehicle from accidents, theft, and natural disasters. Covers third-party liabilities and provides financial security in case of unforeseen events.Ensures peace of mind with customizable coverage options.",
            premium:"Rs.5000/year",
            coverage:"Rs.500000",
            startDate:"11-09-2020",
            endDate:"20-09-2025"
        },
        {name: "Bike Insurance",logo: "bike.png",
            description: "Comprehensive coverage for two-wheelers against accidents, damages, and theft. Protects from third-party liabilities and legal complicetions. Offers add-ons like roadside assistance and engine protection.",
            premium:"Rs.500/month",
            coverage:"Rs.300000",
            startDate:"20-02-2023",
            endDate:"30-03-2024"
        },
        {name: "Commercial Vehicles Insurance",logo: "commercial.png",
            description: "Commercial vehicle insurance covers a range of risks, including accidents, theft, and third-party liabilities, ensuring uninterrupted business operations.It offers rental car and hired/non-owned auto insurance.",
            premium:"Rs.8000/year",
            coverage:"Rs.700000",
            startDate: "21-03-2025",
            endDate:"21-03-2035"
        }
    ]);
    const addPolicy=(newPolicy)=>{
        setPolicies((prev)=>[...prev,{id:prev.length,...newPolicy}]);
    };
    return(
        <PolicyContext.Provider value={{policies,addPolicy}}>{children}</PolicyContext.Provider>
    );
}