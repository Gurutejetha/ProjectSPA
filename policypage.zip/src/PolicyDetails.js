import React, { useContext ,useState} from 'react';
import {useParams,Link} from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import { PolicyContext } from './PolicyContext';


const PolicyDetails=()=>{
    const {policies}=useContext(PolicyContext);
    let {id}=useParams();
    const policyIndex=parseInt(id);
    const [policy, setPolicy]=useState(policies[policyIndex]);
    const [isEditing, setIsEditing]=useState(false);
    const [updatedPolicy,setUpdatedPolicy]=useState(policy);
    const handleChange=(e)=>{
        const {name,value}=e.target;
        setUpdatedPolicy({...updatedPolicy,[name]:value});
    };
    const handleSubmit=(e)=>{
        setPolicy(updatedPolicy);
        setIsEditing(false);
    }
    return(
        <div className='container mt-4'>
            {!isEditing?(
            <div>
            <nav className='navbar navbar-light bg-light d-flex justify-content-between align-items-center'>
                <div className='d-flex align-items-center'>
                <img src={require("./logos.png")} alt="Navbar Icon" style={{width:"70px",height:"70px",marginRight:"10px",marginTop:"25px"}}/>
                <h3 className="navbar-brand mb-0 h1" style={{fontSize:"30px"}}>Vehicle Policies</h3>
                </div>
                <Link to="/" className='btn btn-secondary' style={{backgroundColor:"#ff69b4"}}>Back</Link>
            </nav>
            <div className='card p-4'>
                <div className='d-flex align-items-center justify-content-center'>
                    <img src={require(`./${policy.logo}`)} alt={policy.name} style={{width:"100px",height:"100px"}}/>
                <span className='text-center h5'>{policy.name}</span>
                </div>
                <hr/>
                <div className='mt-3'>
                    <h5>Premium Cost</h5>
                    <p>{policy.premium}</p>
                </div>
                <div className='mt-3'>
                    <h5>Coverage Cost</h5>
                    <p>{policy.coverage}</p>
                </div>
                <div className='mt-3'>
                    <h5>Start Date</h5>
                    <p>{policy.startDate}</p>
                </div>
                <div className='mt-3'>
                    <h5>End Date</h5>
                    <p>{policy.endDate}</p>
                </div>
                <div className='mt-4 d-flex justify-content-center gap-5'>
                    <button className='btn w-45' onClick={()=>setIsEditing(true)} style={{backgroundColor:"#ff69b4",color:"white"}}>Update</button>
                </div>
            </div>
            </div>):(
            <div id='form'>
            <form className='card p-4' onSubmit={handleSubmit}>
                <h4 style={{color:"#ff69b4"}}>Edit Policy Details</h4>
                <label>Name</label>
                <input type='text' name='name' value={updatedPolicy.name} onChange={handleChange} className='form-control mb-2'/>
                <label>Premium Cost</label>
                <input type='text' name='premium' value={updatedPolicy.premium} onChange={handleChange} className='form-control mb-2'/>
                <label>Coverage Cost</label>
                <input type='text' name='coverage' value={updatedPolicy.coverage} onChange={handleChange} className='form-control mb-2'/>
                <label>Start Date</label>
                <input type='text' name='startDate' value={updatedPolicy.startDate} onChange={handleChange} className='form-control mb-2'/>
                <label>End Date</label>
                    <input type='text' name='endDate' value={updatedPolicy.endDate} onChange={handleChange} className='form-control mb-2'/>
                    <div className='mt-4 d-flex justify-content-center gap-5'><button type='submit' style={{color:"white", backgroundColor:"#ff69b4"}}>Save</button>
                    <button type='button' onClick={()=> setIsEditing(false)} style={{color:"white", backgroundColor:"#8a2be2"}}>Cancel</button>
                    </div>
                </form>
            </div>
        )}
        </div>
    )
}
export default PolicyDetails;